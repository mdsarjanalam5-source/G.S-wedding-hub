G.S WEDDING HUB — SHARED PHOTO/VIDEO GALLERY SETUP

IMPORTANT: The shared gallery needs a Firebase project. This ZIP contains code templates; it will NOT connect until you complete these steps.

1) Create a Firebase project at https://console.firebase.google.com/
2) Project settings > General > Your apps > Add app > Web app. Copy the Firebase config.
3) Edit app/src/main/assets/firebase-config.js and replace every PASTE_ value with the exact values from your Firebase Web App config. storageBucket must be copied exactly from Firebase Console.
4) Firebase Console > Authentication > Get started > Sign-in method > enable Email/Password.
5) Authentication > Users > Add user. Create your admin email and a strong unique password. Do NOT use the old demo password.
6) Copy firestore.rules into Firebase Console > Firestore Database > Rules. Replace REPLACE_WITH_ADMIN_EMAIL with the exact admin email. Publish.
7) Create a Storage bucket in Firebase Console. Copy storage.rules into Storage > Rules, replace REPLACE_WITH_ADMIN_EMAIL with the same admin email, and publish.
8) Billing: Firebase Storage may require the Blaze billing plan depending on current Firebase policy/region. Check the console before enabling; usage can incur charges. Set budget alerts.
9) Commit all changes to GitHub. Run Actions > Build G.S Wedding Hub APK. Download the APK artifact/release.
10) Sign into Admin Panel with the Firebase email/password. Upload buttons appear in the gallery and uploads become visible on all devices.

SECURITY NOTES
- No hardcoded admin password is used. Firebase Authentication handles the password.
- Public users can read/download gallery items because this is a public customer gallery. Only the specified admin email can upload/delete according to the rules.
- Firebase web config is not a password. Never put service-account keys or private credentials in the app.
- For stronger admin security, add Firebase App Check and MFA; keep admin email protected.
- Upload limits in the UI: photos 15 MB, videos 100 MB. Storage rules also limit each file to under 100 MB.
- Reviews are still stored locally in this version; the shared feature implemented here is the photo/video gallery.
